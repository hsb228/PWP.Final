package com.naver.sudend;

import java.util.Random;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.naver.sudend.entities.Member;
import com.naver.sudend.service.MemberDao;

@Controller
public class LoginController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@RequestMapping(value = "loginForm", method = RequestMethod.GET)
	public String loginForm() {
		return "login/login";
	}
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String login(@RequestParam String email, @RequestParam String password, HttpSession session) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		Member member = dao.selectOne(email);
		if (member != null) {
			boolean passchk = BCrypt.checkpw(password, member.getPassword());
			if (passchk) {
				session.setAttribute("sessionemail", member.getEmail());
				session.setAttribute("sessionpassword", member.getPassword());
				session.setAttribute("sessionname", member.getName());
				session.setAttribute("sessionlevel", member.getLevel());
				session.setAttribute("sessionphoto", member.getPhoto());
				return "redirect:index";
			} else {
				return "login/login_fail";
			}
		} else {
			return "login/login_fail";
		}
	}
	
	@RequestMapping(value = "logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:index";
	}
	@RequestMapping(value = "emailLossFind", method = RequestMethod.POST)
	@ResponseBody
	public String emailLossFind(String email) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		Member member = dao.selectOne(email);
		String exists = "n";
		if(member != null) {
			Random random = new Random();
			String temppassword=String.format("%04d", random.nextInt(9000));
			member.setPassword(passwordEncoder.encode(temppassword));
			String content = "임시비밀번호["+temppassword+"]";
			MemberController.sendEmail(email, content);
			dao.updateRow(member);
			exists = "y";
		}
		return exists;
	}
}
