package com.naver.sudend;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.naver.sudend.entities.Member;
import com.naver.sudend.service.MemberDao;

@Controller
public class MemberController {

	@Autowired
	private SqlSession sqlSession;
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@RequestMapping(value = "memberInsertForm", method = RequestMethod.GET)
	public String MemberInsertform() {
		return "member/memberInsert";
	}

	@RequestMapping(value = "memberInsert", method = RequestMethod.POST)
	public String MemberInsert(Model model, @ModelAttribute Member member, @RequestParam CommonsMultipartFile imgfile) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		String originalname = imgfile.getOriginalFilename();
		String newfilename = "";
		String realpath = "resources/uploadimages/";
		if (originalname.equals("")) {
			newfilename = "1024.jpg";
		} else {
			int position = originalname.lastIndexOf(".");
			String ext = originalname.substring(position);
			newfilename = member.getEmail() + ext;
			try {
				String path = "D:/PWPFinal/PracticeWebProject/src/main/webapp/resources/uploadimages/";
				byte bytes[] = imgfile.getBytes();
				BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(path + newfilename));
				output.write(bytes);
				output.flush();
				output.close();
			} catch (Exception e) {
				System.out.println("file error:" + e.getMessage());
			}
		}
		member.setPhoto(realpath + newfilename);
		String passencode = passwordEncoder.encode(member.getPassword());
		member.setPassword(passencode);
		member.setInput_date(currentDate());
		int result = dao.insertRow(member);
		if (result > 0) {
			model.addAttribute("msg", "회원 가입에 성공하였습니다");
		} else {
			model.addAttribute("msg", "오류가 발생하였습니다.");
		}
	    //ModelAndView mav = new ModelAndView("member/member_result");
		//mav.addObject(msg,msg);
		return "member/Resultpage";
	}
	
	@RequestMapping(value = "emailauth", method = RequestMethod.POST)
	@ResponseBody 
	public String emailauth(@RequestParam String email) { 
		String authnum = randomNum(); 
		sendEmail(email, authnum); 
		return authnum; 
		}  
	
	String randomNum() {
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i <= 6; i++) { int n = (int) (Math.random() * 10);
		buffer.append(n); } 
		return buffer.toString(); 
		}

	static void sendEmail(String email, String content) { 
		String host ="smtp.gmail.com"; 
		String subject = "DWP 인증번호"; 
		String fromName = "DWP 관리자";
		String from = "backupteam01@gmail.com"; 
		String to1 = email; 
		try { 
			Properties props = new Properties(); 
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.transport.protocol", "smtp"); 
			props.put("mail.smtp.host", host); 
			props.setProperty("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory"); 
			props.put("mail.smtp.port", "587"); // 465 or 587 
			props.put("mail.smtp.user", from); 
			props.put("mail.smtp.auth", "true"); 
			
			Session mailSession = Session.getInstance(props,
			  new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("backupteam01", "skwgvfwvllnhtvob");
					} 
				}); 
				Message msg = new MimeMessage(mailSession);
				msg.setFrom(new InternetAddress(from, MimeUtility.encodeText(fromName,"UTF-8", "B")));
 
				InternetAddress[] address1 = { new InternetAddress(to1) };
				msg.setRecipients(Message.RecipientType.TO, address1);
				msg.setSubject(subject); msg.setSentDate(new java.util.Date());
				msg.setContent(content, "text/html;charset=euc-kr"); 
				Transport.send(msg);
				} catch (Exception e) { 
					System.out.println("email error error:"+e.getMessage());
				} 
			}

	@RequestMapping(value = "confirmEmail", method = RequestMethod.POST)
	@ResponseBody
	public String confirmEmail(@RequestParam String email) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		int exists = dao.selectConfirm(email);
		return exists + "";
		}

	public String currentDate() {
		Date today = new Date();
		SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd");
		SimpleDateFormat time = new SimpleDateFormat("hh:mm:ss a");
		String curtime = date.format(today) + " " + time.format(today);
		return curtime;
		}
	
	@RequestMapping(value = "memberSearch", method = RequestMethod.GET)
	public String membersearch(Model model) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		ArrayList<Member> members = dao.selectAll();
		model.addAttribute("members", members);
		return "member/memberSearch";
		}
	
	@RequestMapping(value = "memberUpdateForm", method = RequestMethod.GET)
	public String memberupdateform(Model model,@RequestParam String email) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class); 
		Member member=dao.selectOne(email);
		String decoding = passwordEncoder.encode(member.getPassword());
		member.setPassword(decoding);
		model.addAttribute("member",member);
		return "member/memberUpdate";
		}
	
	@RequestMapping(value = "memberUpdate", method = RequestMethod.POST)
	public String memberupdate(Model model,@ModelAttribute Member member,@RequestParam String email, @RequestParam CommonsMultipartFile imgfile) {
		MemberDao dao = sqlSession.getMapper(MemberDao.class);
		
		String originalname = imgfile.getOriginalFilename();	
		String newfilename = "";
		String realpath = "resources/uploadimages/";
		if(originalname.equals("")) {
			member.setPhoto(member.getBeforephoto());
		} else {
			int position = originalname.lastIndexOf(".");
			String ext = originalname.substring(position);
			newfilename = member.getEmail()+ext;
			try {
				String path = "D:/DWPFinal/DeepWebProject/src/main/webapp/resources/uploadimages/";
				byte bytes[] = imgfile.getBytes();
				BufferedOutputStream output = 
						new BufferedOutputStream(new FileOutputStream(path+newfilename));
				output.write(bytes);
				output.flush();
				output.close();
				member.setPhoto(realpath + newfilename);
			} catch (Exception e) {
				System.out.println("file error:"+e.getMessage());
			}	
		}
		if(!member.getBeforepassword().equals("member.getPassword()")) {
			String passencode=passwordEncoder.encode(member.getPassword());
			member.setPassword(passencode);
		} 
		int result=dao.updateRow(member);
		String msg = "회원 정보가 갱신되었습니다";
		if (result != 1) {
			msg="오류가 발생하였습니다.";
		}
		model.addAttribute("msg",msg);
		return "member/Resultpage";
		}
}
