package com.naver.sudend.service;

import com.naver.sudend.entities.Member;

public interface MemberDao {
	int selectConfirm(String email);
	int insertRow(Member member);
	Member selectOne(String email);
	int updateRow(Member member);
}
