package com.naver.sudend.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.naver.sudend.entities.Member;

public interface MemberDao {
	int selectConfirm(String email);
	int insertRow(Member member);
	Member selectOne(String email);
	ArrayList<Member> selectAll();
	int updateRow(Member member);
	int deleteOne(String email);
	void updateLevelAll(HashMap data);
}
