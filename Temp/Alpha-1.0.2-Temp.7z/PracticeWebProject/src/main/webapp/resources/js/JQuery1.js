	//Member Insert Section(normal function)
	function phone2_lengthchk(code) {
		if(code.value.length == 4){
			document.memberInsertForm.phone3.focus();
		}
	}
	
	function zipcodefind() {
		new daum.Postcode({
            oncomplete: function(data) {
                var fullRoadAddr = data.roadAddress;
                var extraRoadAddr = ''; 
                
                if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                    extraRoadAddr += data.bname;
                }
                
                if(data.buildingName !== '' && data.apartment === 'Y'){
                   extraRoadAddr += (extraRoadAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                }
                
                if(extraRoadAddr !== ''){
                    extraRoadAddr = ' (' + extraRoadAddr + ')';
                }
                
                if(fullRoadAddr !== ''){
                    fullRoadAddr += extraRoadAddr;
                }
                
                document.getElementById('postno').value = data.zonecode; //5자리 새우편번호 사용
                document.getElementById('addr1').value = fullRoadAddr;
                document.getElementById('addr2').value = data.jibunAddress;
            },
            onclose:function(state) {
                if(state === 'FORCE_CLOSE'){
                } else if(state === 'COMPLETE_CLOSE'){
                }
            }
        }).open();
	}
	
	function validateEmail(sEmail) {
		var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if (filter.test(sEmail)) {
			return true;
		}
		else {
			return false;
			}
		}
	
	function memberDeleteFunc(email){
		$(document).ready(function(){
		$('.modal-body').text("삭제하시겠습니까?");
		$('.modal_btn1').text('확인');
		$('#msModal').modal('show');
		$('.msmodal_btn1').on('click',function(){
			location.replace("memberDelete?email="+email);
			$('#msModal').modal('hide');
			return;
			});
		$('.msmodal_btn2').on('click',function(){
			$('#msModal').modal('hide');
			return;
			});
		});
	}
	
	$(document).ready(function(){
		//Login Section	
		$('#Logout').on('click',function(){
			window.location.assign('logout');
		});
		
		$('#passfind').on('click',function(){
			$('#loginModal2').modal('hide');
			$('#loginModal').modal('show');
			$('#findbtn').on('click',function(){
				$.ajax({
					type : 'POST',
					data : "email="+$('#findemail').val(),
					datatype : 'json',
					url : 'emailLossFind',
					success : function(data) {
						if(data == 'n') {
							$('#loginmodal2-body').text("존재하지 않는 E-mail입니다.")
							$('#loginModal2').modal('show');
						} else {
							$('#loginmodal2-body').text("새 비밀번호를 전송했습니다.")
							$('#loginModal2').modal('show');
						}	
					},						   						
					error:function(xhr,status,error){
						alert("ajax error:"+status.code);
					}
				});
			});
		});
		
		//Member Insert Section(javascript)
		$('#image').on('click',function(){
			$('input[type=file]').click();
			return false;
		});
		$('#photo').change(function(event){
			var tmppath = URL.createObjectURL(event.target.files[0]);
			$('#image').attr('src',tmppath);
		});
		
		$('#emailauth').on('click',function(){
			var email = $('#email').val();
		  	if(email == ""){
	  			$('.modal-body').text("E-mail을 입력하세요!");
		  		$('#memberModal').modal('show');
		  		$('.modal_btn1').on('click',function(){
			  		$('#memberModal').modal('hide');
			  	});
	  		$('.modal_btn2').hide();
	  		return;
			}
			$.ajax({
				type : 'POST',
				data : "email="+email,
				datatype : 'json',
				url : 'emailauth',
				success : function(data) {
					alert("메일이 발송되었습니다."); 
					return false;
				},
				error:function(request,status,error){
					alert(status);
				}
			});
		});
		
		$('#confirmemail').on('click',function(){
			var email = $('#email').val();
			var emailresult = validateEmail(email);
			if(emailresult) {
				$.ajax({
					type : 'POST',
					data : "email="+email,
					datatype : 'json',
					url : 'confirmEmail',
					success : function(data) {
						if(data == 0) {
							$('.modal-body').text("사용 가능한 E-mail입니다.");
							$('.modal_btn1').text('사용');
							$('#memberModal').modal('show');
							$('.modal_btn1').on('click',function(){
								$('#confirm_yn').val("y");
								$('#memberModal').modal('hide');
								$('#password').focus();
							});	
						} else {
							$('.modal-body').text("중복된 E-mail입니다.");
							$('.modal_btn1').text('확인');
							$('.modal_btn2').hide();
							$('#memberModal').modal('show');
							$('.modal_btn1').on('click',function(){
								$('#memberModal').modal('hide');
								$('#email').val("");
								$('#email').focus();
								return;
							});
						}
					}
				});
			} else {
				$('.modal-body').text("올바른 E-mail 형식을 입력하세요!");
				$('#memberModal').modal('show');	
				$('.modal_btn1').on('click',function(){
					$('#memberModal').modal('hide');
					});
				$('.modal_btn2').hide();
				return;
			}		
		});
		
		$('#memberInsert').on('click',function(){
			if($('#confirm_yn').val() == "n") {
				$('.modal-body').text("E-mail 중복 체크는 필수입니다.");
				$('.modal_btn1').text('확인');
				$('.modal_btn2').hide();
				$('#memberModal').modal('show');
				$('.modal_btn1').on('click',function(){
					$('#memberModal').modal('hide');
					return;
				});
			} 
		});
		//Member Update Section
		$('#updateimage').on('click',function(){
			$('input[type=file]').click();
			return false;
		});	
		$('#updatephoto').change(function(event){
			var tmppath = URL.createObjectURL(event.target.files[0]);
			$('#updateimage').attr('src',tmppath);
		});
		$('#updatepassword').on('click',function(){
			$('#updatepassword').val("");
			$('#repassword').val("");
		});	
		$('#updatesave').on('click',function(){
			$('.modal-body').text("수정하시겠습니까?");
			$('#muModal').modal('show');
			$('.modal_btn1').on('click',function(){
				$('#memberUpdateForm').submit();
				$('#muModal').modal('hide');					
			});
			$('.modal_btn2').on('click',function(){
				$('#muModal').modal('hide');
				return;
			});		
		});
		//Member Search Section
		$('#allchk').on('click',function(){
			if( $(this).is(':checked')){
				$('input[name=unitchk]').prop('checked',true);
			} else {
				$('input[name=unitchk]').prop('checked',false);
			}
		});
		$('#selecteddel').on('click',function(){
			var checkboxarr = [];
			$("input[name='unitchk']:checked").each(function(){
				checkboxarr.push($(this).val());
			});
			if(checkboxarr.length < 1) {
				$('.modal-body').text("삭제할 항목을 선택하세요!");
				$('.msmodal_btn1').text('확인');
				$('.msmodal_btn2').hide();
				$('#msModal').modal('show');
				$('.msmodal_btn1').on('click',function(){
					$('#msModal').modal('hide');
					return;
				});
			} else {
				$('.modal-body').text("선택된 계정을 삭제하시겠습니까?");
				$('.msmodal_btn1').text('확인');
				$('#msModal').modal('show');
				$('.msmodal_btn1').on('click',function(){
					location.replace("memberSelectDelete?checkboxarr="+checkboxarr);
					$('#msModal').modal('hide');
					return;
				});
				$('.msModal').on('click',function(){
					$('#msModal').modal('hide');
					return;
				});
			}
		});		
		$('#levelupdate').on('click',function(){
			$('.modal-body').text("레벨을 수정하시겠습니까?");
			$('.msmodal_btn1').text('확인 및 수정');
			$('#msModal').modal('show');
			$('.msmodal_btn1').on('click',function(){
				var emailarr = [];
				var levelarr = [];
				$("input[name='email']").each(function(){
					emailarr.push($(this).val());
				});
				$("select[name='level']").each(function(){
					levelarr.push($(this).val());
				});
				window.location.assign("memberLevelUpdate?emailarr="+emailarr+"&levelarr="+levelarr);
				$('#msModal').modal('hide');
			});
			$('.msmodal_btn2').on('click',function(){
				$('#msModal').modal('hide');			
			});
		});
		
	});				