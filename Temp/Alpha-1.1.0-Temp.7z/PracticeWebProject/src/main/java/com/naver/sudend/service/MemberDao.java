package com.naver.sudend.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.naver.sudend.entities.Member;

public interface MemberDao {
	int insertRow(Member member);
	Member selectOne(String email);
	ArrayList<Member> selectAll();
	int selectConfirm(String email);
	int updateRow(Member member);
	void updateLevelAll(HashMap data);
	int deleteOne(String email);
}
