package com.naver.sudend.service;

import java.util.ArrayList;

import com.naver.sudend.entities.Board;
import com.naver.sudend.entities.BoardPaging;

public interface BoardDao {
	int insertRow(Board board);
	
	int selectRowCount(String find);
	
	ArrayList<Board> pageList(BoardPaging boardpaging);
}
