package com.naver.sudend.service;

import java.util.ArrayList;

import com.naver.sudend.entities.Board;
import com.naver.sudend.entities.BoardPaging;

public interface BoardDao {
	int insertRow(Board board);
	int selectRowCount(String find);
	ArrayList<Board> pageList(BoardPaging boardpaging);
	Board selectOne(int b_seq);
	void updateHit(int b_seq);
	int updateRow(Board board);
	int insertReplyRow(Board board);
	int deleteRow(int b_seq);
	ArrayList<Board> boardDataTable();
}
