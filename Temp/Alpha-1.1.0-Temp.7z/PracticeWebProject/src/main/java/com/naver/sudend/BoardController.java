package com.naver.sudend;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.naver.sudend.entities.Board;
import com.naver.sudend.entities.BoardPaging;
import com.naver.sudend.service.BoardDao;

@Controller
public class BoardController {
	@Autowired
	private SqlSession sqlSession;
	@Autowired
	private BoardPaging boardpaging;
	static String find;
	
	// Board Insert
	@RequestMapping(value = "boardInsertForm", method = RequestMethod.GET)
	public String boardInsertForm() {
		return "board/boardInsert";
	}
	
	@RequestMapping(value = "boardInsert", method = RequestMethod.POST)
	public String boardInsert(Model model,@ModelAttribute Board board,@RequestParam CommonsMultipartFile file) {
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		
		//picture set
		String path = "D:/Alpha1.1.0/PracticeWebProject/src/main/webapp/resources/attachFiles/";
		String realpath = "resources/attachFiles/";
		String originalname = file.getOriginalFilename();
		String filetime = System.currentTimeMillis()+"";
		if(!originalname.equals("")) {
			try {
				byte bytes[] = file.getBytes();
				BufferedOutputStream output =
						new BufferedOutputStream(new FileOutputStream(path+filetime+"-"+originalname));
				output.write(bytes);
				output.flush();
				output.close();
				board.setB_attach(realpath+filetime+"-"+originalname);
				} catch (Exception e) {
					System.out.println("file err:"+e.getMessage());
				}
			}
		//ip set
		InetAddress ip=null;
		try {
			ip = InetAddress.getLocalHost();
		} catch (Exception e) {
			System.out.println("ip conversion error:"+e.getMessage());
		}
		board.setB_ip(ip.getHostAddress());
		//date set
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		board.setB_date(format.format(date));
		//insertRow
		int result=dao.insertRow(board);
		String msg = "게시글 등록에 실패했습니다.";
		if(result > 0) {
			msg = "게시글 등록에 성공하였습니다.";
		}
		model.addAttribute("msg", msg);
		return "board/Resultpage";
    }			
	
	// Board Search
	@RequestMapping(value = "boardPage", method = RequestMethod.GET)
	public String boardSearch(Model model, @RequestParam String find) {
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		this.find = find;
		int rowcount = dao.selectRowCount(find);
		int pagesize = 10;
		int startrow = (0) * pagesize;
		int endrow = pagesize;
		boardpaging.setFind(find);
		boardpaging.setStartrow(startrow);
		boardpaging.setEndrow(endrow);
		ArrayList<Board> boards = dao.pageList(boardpaging);

		int absPage = 1;
		if (rowcount % pagesize == 0)
			absPage = 0;
		int pageCount = rowcount / pagesize + absPage;
		int[] pages = new int[pageCount];
		for (int i = 0; i < pageCount; i++) {
			pages[i] = i + 1;
		}
		model.addAttribute("boards", boards);
		model.addAttribute("pages", pages);
		return "board/boardPage";
	}
	@RequestMapping(value = "boardPageSelected", method = RequestMethod.GET)
	public String boardSearch(Model model, int page) {
		BoardDao dao = sqlSession.getMapper(BoardDao.class);
		int rowcount = dao.selectRowCount(find);
		int pagesize = 10;
		int startrow = (page - 1) * pagesize;
		int endrow = pagesize;
		boardpaging.setFind(find);
		boardpaging.setStartrow(startrow);
		boardpaging.setEndrow(endrow);
		ArrayList<Board> boards = dao.pageList(boardpaging);

		int absPage = 1;
		if (rowcount % pagesize == 0)
			absPage = 0;
		int pageCount = rowcount / pagesize + absPage;
		int[] pages = new int[pageCount];
		for (int i = 0; i < pageCount; i++) {
			pages[i] = i + 1;
		}
		model.addAttribute("boards", boards);
		model.addAttribute("pages", pages);
		return "board/boardPage";
	}
	@RequestMapping(value = "boardDownload", method = RequestMethod.GET)
 	public ModelAndView boardDownload(@RequestParam String b_attach) {
		File file = new File("D:/Alpha1.1.0/PracticeWebProject/src/main/webapp/"+b_attach); 
		return new ModelAndView("download","downloadFile",file);
	}
}
