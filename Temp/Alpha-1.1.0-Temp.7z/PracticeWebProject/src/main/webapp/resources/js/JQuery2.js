	$(document).ready(function(){
//Board Insert Section			
			$('#file').change(function(e){
				var attachpath = e.target.files[0].name;
				$('#attachfile').val(attachpath);
			});
			$('#boardreset').on('click',function(){
				CKEDITOR.instances["b_content"].setData('');
				$('#boardInsertForm').trigger("reset");			
			});
			$('#boardupdate').on('click',function(){
				$('#boardModal').modal('show');
				$('#modalmsg').text("수정하시겠습니까?");
				$('.modal-title').text("");
				$('#boardbtn').on('click',function(){
					$('#boardUpdateForm').submit();
					});
				});
			$('#boarddelete').on('click',function(){
				$('#boardModal').modal('show');
				$('#modalmsg').text("삭제하시겠습니까?");
				$('.modal-title').text("");
				$('#boardbtn').on('click',function(){
					location.replace("boardDelete?b_seq="+$('#b_seq').val()+"&b_beforeattach="+$('#b_beforeattach').val());
					});
				});
			$('#Replysave').on('click',function(){
				var text = CKEDITOR.instances.b_content.getData();
				if(text == "") {
					$('#replyModal').modal('show');
					$('#modalmsg').text("내용을 입력하세요");
					$('.modal-title').text("");
					$('#replybtn').text("확인");
					$('#replycancelbtn').hide();
					$('#replybtn').on('click',function(){
						$('#replyModal').modal('hide');			
						});
						return;
					} else {
						$('#boardReplyForm').submit();
					}	
			});
			$('#replyreset').on('click',function(){
				CKEDITOR.instances["b_content"].setData('');
				$('#boardReplyForm').trigger("reset");			
			});
		});		
			

		
	