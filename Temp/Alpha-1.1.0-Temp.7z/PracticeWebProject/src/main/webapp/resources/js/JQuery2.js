	$(document).ready(function(){
//Board Insert Section			
			$('#file').change(function(e){
				var attachpath = e.target.files[0].name;
				$('#attachfile').val(attachpath);
			});
			
			$('#boardreset').on('click',function(){
				CKEDITOR.instances["b_content"].setData('');
				$('#boardInsertForm').trigger("reset");			
			});
	});	

		
	