package com.naver.sudend.service;

import com.naver.sudend.entities.Member;

public interface MemberDao {
	int insertRow(Member member);
	int updateRow(Member member);
	int selectConfirm(String email);
	Member selectOne(String email);
}
