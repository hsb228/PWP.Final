package com.naver.sudend.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.naver.sudend.entities.Member;

public interface MemberDao {
	int insertRow(Member member);
	int updateRow(Member member);
	int deleteOne(String email);
	int selectConfirm(String email);
	Member selectOne(String email);
	ArrayList<Member> selectAll();
	void updateLevelAll(HashMap data);
}
