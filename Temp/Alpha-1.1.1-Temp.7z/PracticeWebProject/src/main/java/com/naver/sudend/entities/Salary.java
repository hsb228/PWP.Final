package com.naver.sudend.entities;

import org.springframework.stereotype.Component;

import lombok.Data;
@Data
@Component
public class Salary {
	private String empno; //pk
	private String dept; //select box
	private String name;
	private String input_date;
	private String birth_date; //date picker
	private int partner;
	private int dependent20;
	private int dependent60;
	private int disabled;
	private int womanpower;
	private int pay;  //기본급
	private int extra; //수당
	private String yn;  
}
