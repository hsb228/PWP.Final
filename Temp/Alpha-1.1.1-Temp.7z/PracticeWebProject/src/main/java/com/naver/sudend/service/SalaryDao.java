package com.naver.sudend.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.naver.sudend.entities.Dept;
import com.naver.sudend.entities.Salary;
import com.naver.sudend.entities.SalaryRoll;

public interface SalaryDao {
	int empnoConfirm (String empno);
	int insertRow (Salary salary);
	ArrayList<Salary> selectSalaryAll();
	ArrayList<Dept> selectAllDept();
	Salary selectOne(String empno);
	int updateRow(Salary salary);
	int deleteRow(String empno);
	void salaryrollInsertRow(SalaryRoll salaryroll);
	ArrayList<SalaryRoll> salaryrollList(HashMap yyyymm);
	void salaryrollDelete(HashMap rollkey);
}
