package com.naver.sudend.entities;

import lombok.Data;

@Data
public class Member {
	private String email;
	private String beforepassword;
	private String password;
	private String name;
	private String phone1;
	private String phone2;
	private String phone3;
	private String postno;
	private String addr1;
	private String addr2;
	private String photo;
	private String beforephoto;
	private String input_date;
	private int level;
}
	
	
