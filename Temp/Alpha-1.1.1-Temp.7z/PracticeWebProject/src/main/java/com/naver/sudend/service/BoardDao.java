package com.naver.sudend.service;

import java.util.ArrayList;

import com.naver.sudend.entities.Board;
import com.naver.sudend.entities.BoardPaging;

public interface BoardDao {
	int insertRow(Board board);
	Board selectOne(int b_seq);
	ArrayList<Board> pageList(BoardPaging boardpaging);
	int selectRowCount(String find);
	int updateRow(Board board);
	int deleteRow(int b_seq);
	void updateHit(int b_seq);
	int insertReplyRow(Board board);
}
